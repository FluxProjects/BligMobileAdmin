@extends('layout.layout')
@section('title')
Create Membership Plane
@endsection
@section('css')

@endsection
@section('content')
<form method="post" action="{{ url("membership-plane/insert") }}" enctype="multipart/form-data">
  {{ csrf_field() }}
 <div class="container-fluid">
   <div class="row">
     <div class="col-sm-12">
       <div class="card">
         <div class="card-body">
           <div class="row">
             <div class="col-sm-4">
               <label>Type:</label><span style="color:red">*</span>
               <select class="form-control" name="type" name="type" required="">
                 <option disabled="" value="" selected="">Select Type</option>
                 <option >Entrepreneur</option>
                 <option >Investor</option>
               </select>
             </div>
             <div class="col-sm-4">
               <label>Group Type:</label><span style="color:red">*</span>
               <select class="form-control" name="group_type" required="">
                 <option disabled="" selected="">Select Group</option>
                 @foreach( $group as $key => $g )
                  <option value="{{ $g->id }}">{{ $g->group_name }}</option>
                 @endforeach
               </select>
             </div>
             <div class="col-sm-4">
               <label>Membership Name:</label><span style="color:red">*</span>
               <input type="text" name="membership_name" class="form-control" placeholder="Membership Name" required="">
             </div>
             <div class="col-sm-4 mt-3">
               <label>Durations(months):</label><span style="color:red">*</span>
               <input type="type" name="membership_duration" class="form-control" placeholder="Durations" required="">
             </div>

             <div class="col-sm-4 mt-3">
               <label>Cost:</label><span style="color:red">*</span>
               <input type="text" name="membership_cost" class="form-control" placeholder="Cost" required="">
             </div>
             
           </div>
           <div class="row">
             <div class="col-sm-4 mt-3">
               <label>Description:</label>
               <textarea class="form-control" name="description"></textarea>
             </div>
           </div>
           <button type="Submit" class="btn btn-dark mt-3">Submit</button>
         </div>
       </div>
     </div>
   </div>
 </div>
</form>

@endsection
@section('jquery')
 
@endsection